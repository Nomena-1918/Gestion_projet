<template>
  <div class="app-wrapper">
    <div class="ecran-travail">
      <!-- Header avec titre de l'épisode -->
      <header class="">
        <div class="navigation">
          <button class="nav-btn" @click="goToPrevPage" :disabled="!hasPrev || isLoading">Précédent</button>
          <button class="nav-btn" @click="goToNextPage" :disabled="!hasNext || isLoading">Suivant</button>
        </div>

        <h2> Épisode {{ currentEpisode?.ordre }} : </h2><br>     

        <div class="title-episode">
        <label> {{ currentEpisode?.titre || 'Chargement...' }} </label>

        <span class="icon-edit" @click="startEditEpisode" v-if="currentEpisode"><i class="fas fa-pen icon" style="background: none;"></i></span> <br>
        </div>
        
      </header>

      <!-- Navigation par numéros d'épisodes -->
        <div class="episode-navigation">
          <span
            v-for="episode in episodes"
            :key="episode.idEpisode"
            class="episode-number"
            :class="{ 'active': episode.idEpisode === currentEpisode?.idEpisode, 'new-episode': episode.idEpisode === newlyCreatedEpisodeId }"
            @click="selectEpisode(episode.idEpisode)"
          >
            {{ episode.ordre }}
            <span v-if="episode.idEpisode === newlyCreatedEpisodeId" class="blinking-icon">✨</span>
          </span>
        </div>

      <!-- Indicateur de chargement -->
      <div v-if="isLoading" class="loading">Chargement en cours...</div>

      <!-- Message d'erreur -->
      <div v-if="error && !isLoading" class="error-message">
        {{ error }}
        <button class="retry-btn" @click="retryFetch">Réessayer</button>
      </div>

      <div class="liens">
        <button class="add-scene-btn" @click="goToAddEpisode"><i class="fas fa-plus-circle icon" style="color: #21294F;"></i> Episode</button>     
        <button class="add-scene-btn" @click="goToAddSequence"><i class="fas fa-plus-circle icon" style="color: #21294F;"></i> Séquence</button>
        <button class="add-scene-btn" @click="goToAddLieu"><i class="fas fa-plus-circle icon" style="color: #21294F;"></i> Lieu</button>
        <button class="add-scene-btn" @click="goToAddPlateau"><i class="fas fa-plus-circle icon" style="color: #21294F;"></i> Plateau</button>
        <button class="add-scene-btn" @click="goToAddComedien"><i class="fas fa-plus-circle icon" style="color: #21294F;"></i> Comedien</button>
        <button class="add-scene-btn" @click="goToAddPersonnage"><i class="fas fa-plus-circle icon" style="color: #21294F;"></i> Personnage</button>
      </div>

      <div class="#">
        <h2>Les séquences :</h2>
      </div>

      <div class="#">
        <!-- Navigation par numéros de séquences -->
        <div v-if="currentEpisode && !isLoading" class="sequence-navigation">
          <span
            v-for="(sequence, index) in sequences"
            :key="sequence.idSequence"
            class="sequence-number"
            :class="{ 'active': sequence.idSequence === currentSequence?.idSequence, 'new-sequence': sequence.idSequence === newlyCreatedSequenceId }"
            @click="selectSequence(sequence.idSequence)"
          >
            <span v-if="index > 0"></span>
            {{ sequence.ordre }}
            <span v-if="sequence.idSequence === newlyCreatedSequenceId" class="blinking-icon">✨</span>
          </span>
        </div>
      </div>

      

      <!-- Contenu de la séquence -->
      <main class="sequence-page" v-if="currentSequence && !isLoading">
        <h2>
          Séquence 0{{ currentSequence.ordre }} : {{ currentSequence.titre }}
          <span class="icon-edit" @click="startEditSequence(currentSequence)"><i class="fas fa-pen icon" style="color: #17a2b8;"></i></span>
          <span class="icon-delete" @click="deleteSequence(currentSequence.idSequence)"><i class="fas fa-trash icon" style="color: #dc3545;"></i></span>
          <span class="comment-icon" @click="toggleSequenceCommentSection">
            <h3><i class="fas fa-comments icon" style="color: #21294F;"></i>{{ sequenceCommentCount }}</h3>
          </span>
        </h2>

        <!-- Section commentaires séquence -->
        <div v-if="showSequenceCommentSection" class="comment-section">
          <h4><i class="fas fa-comments icon" style="color: #21294F;"></i>Commentaires sur la séquence</h4>
          <div class="add-comment">
            <textarea v-model="newSequenceComment" placeholder="Ajouter un commentaire..." rows="3"></textarea>
            <button @click="addSequenceComment" class="add-comment-btn"><i class="fas fa-plus-circle icon"></i>Ajouter</button>
          </div>
          <div class="comments-list">
            <div v-for="comment in sequenceComments" :key="comment.id" class="comment-item">
              <div class="comment-header">
                <span class="comment-author">{{ comment.utilisateurNom }}</span>
                <span class="comment-date">{{ formatDate(comment.creeLe) }}</span>
              </div>
              <div class="comment-content">
                {{ comment.contenu }}
              </div>
              <div class="comment-actions" v-if="comment.utilisateurId === user.id">
                <button @click="deleteSequenceComment(comment.id)" class="delete-comment-btn"><i class="fas fa-trash icon"></i>Supprimer</button>
              </div>
            </div>
          </div>
        </div>
        
        <p><strong>Synopsis:</strong> {{ currentSequence.synopsis || 'Aucun synopsis' }}</p>
        <p><strong>Statut:</strong> {{ currentSequence.statutNom || 'Non défini' }}</p>

        <!-- Section scènes -->
        <div class="scenes-section">
          <div class="section-header">
            <h3>Scènes</h3>
            <button class="add-scene-btn" @click="goToAddScene"><i class="fas fa-plus-circle icon" style="color: #21294F;"></i> Scène</button>
          </div>

          <!-- Liste des scènes -->
          <div class="scenes-list">
            <div v-for="scene in currentSequence.scenes" :key="scene.idScene" class="scene-card">
              <h3>
                Scène {{ scene.ordre }}: {{ scene.titre }}
                <span class="icon-edit" @click="startEditScene(scene)"><i class="fas fa-pen icon" style="color: #17a2b8;"></i></span>
                <span class="icon-delete" @click="deleteScene(scene.idScene)"><i class="fas fa-trash icon" style="color: #dc3545;"></i></span>
                <span class="comment-icon" @click="toggleSceneCommentSection(scene)">
                  <i class="fas fa-comments icon" style="color: #21294F;"></i> {{ getSceneCommentCount(scene.idScene) }}
                </span>
              </h3>

              <!-- Section commentaires scène -->
              <div v-if="showSceneCommentModal && selectedScene?.idScene === scene.idScene" class="comment-section">
                <h4>Commentaires sur la scène</h4>
                <div class="add-comment">
                  <textarea v-model="newSceneComment" placeholder="Ajouter un commentaire..." rows="3"></textarea>
                  <button @click="addSceneComment" class="add-comment-btn"><i class="fas fa-plus-circle icon"></i>Ajouter</button>
                </div>
                <div class="comments-list">
                  <div v-for="comment in sceneComments" :key="comment.id" class="comment-item">
                    <div class="comment-header">
                      <span class="comment-author">{{ comment.utilisateurNom }}</span>
                      <span class="comment-date">{{ formatDate(comment.creeLe) }}</span>
                    </div>
                    <div class="comment-content">
                      {{ comment.contenu }}
                    </div>
                    <div class="comment-actions" v-if="comment.utilisateurId === user.id">
                      <button @click="deleteSceneComment(comment.id)" class="delete-comment-btn"><i class="fas fa-trash icon"></i>Supprimer</button>
                    </div>
                  </div>
                </div>
                <button @click="closeSceneCommentModal" class="close-comments-btn">Fermer</button>
              </div>

              <p><strong>Synopsis:</strong> {{ scene.synopsis || 'Aucun synopsis' }}</p>
              <p><strong>Statut:</strong> {{ scene.statutNom || 'Non défini' }}</p>

              <div class="section-header">
                <h4><i class="fas fa-map-pin icon" style="color: #dc3545;"></i>Lieux et Plateaux:</h4>
                <button class="add-lieu-btn" @click="openAddLieuModal(scene)"><i class="fas fa-plus-circle icon" style="color: #21294F;"></i>Lieu/Plateau</button>
              </div>
              <!-- Lieux et Plateaux -->
              <div class="lieux-plateaux" v-if="scene.sceneLieus?.length">
                <ul>
                  <li v-for="sceneLieu in scene.sceneLieus" :key="sceneLieu.id">
                    <strong>{{ sceneLieu.lieuNom || 'Lieu inconnu' }}</strong>
                    <span v-if="sceneLieu.plateauNom"> - <strong>Plateau:</strong> {{ sceneLieu.plateauNom }}</span>
                    <span class="icon-delete" @click="deleteSceneLieu(sceneLieu.id)"><i class="fas fa-trash icon" style="color: #dc3545;"></i></span>
                    <p v-if="sceneLieu.descriptionUtilisation">Description: {{ sceneLieu.descriptionUtilisation }}</p>
                  </li>
                </ul>
              </div>
              <p v-else>Aucun lieu ou plateau associé.</p>

              <div class="section-header">
                    <h4><i class="fas fa-comments icon" ></i>Dialogues:</h4> 
                </div>
              <!-- Dialogues -->
              <div class="dialogues" v-if="scene.dialogues?.length">
                <ul>
                  <li v-for="dialogue in scene.dialogues" :key="dialogue.id">
                    <strong>{{ dialogue.personnageNom || 'Narrateur' }}:</strong> {{ dialogue.texte }} <br><br>
                    <span v-if="dialogue.observation">{{ dialogue.observation }}</span>
                    <!-- <span class="icon-edit" @click="startEditDialogue(dialogue)"><i class="fas fa-pen icon" style="color: #17a2b8;"></i></span> -->
                    <span class="icon-delete" @click="deleteDialogue(dialogue.id)"><i class="fas fa-trash icon" style="color: #dc3545;"></i></span>
                    <span class="comment-icon" @click="toggleDialogueCommentSection(dialogue)">
                      <i class="fas fa-comment icon" style="color: #21294F;"></i> {{ getDialogueCommentCount(dialogue.id) }}
                    </span>
                  </li>
                </ul>
              </div>
              
              <p v-else>Aucun dialogue associé.</p>  
              <div class="section-header">
                  <h4><i class="fas fa-comments icon" ></i></h4> 
                  <button class="add-dialogue-btn" @click="goToAddDialogue(scene.idScene)"><i class="fas fa-plus-circle icon" style="color: #21294F;"></i>Dialogue</button>
              </div>                    
            
            </div>
          </div>
        </div>
      </main>
      <div v-else-if="!isLoading" class="no-data">
        <p>Aucune séquence disponible pour cet épisode.</p>
      </div>

      <!-- Modale pour éditer l'épisode -->
      <div v-if="showEditEpisodeModal" class="modal-overlay">
        <div class="modal-content">
          <div class="modal-header">
            <h3>
              <i class="fas fa-edit icon"></i>
              Modifier l'épisode
            </h3>
            <button @click="closeEditEpisodeModal" class="close-btn"><i class="fas fa-times icon"></i></button>
          </div>
          <form @submit.prevent="saveEditedEpisode" class="edit-form">
            <div class="form-group">
              <label for="edit-episode-titre">Titre</label>
              <input
                type="text"
                id="edit-episode-titre"
                v-model="editingEpisode.titre"
                required
                class="form-input"
              />
            </div>
            <div class="form-group">
              <label for="edit-episode-synopsis">Synopsis</label>
              <textarea
                id="edit-episode-synopsis"
                v-model="editingEpisode.synopsis"
                rows="4"
                class="form-textarea"
              ></textarea>
            </div>
            <div class="form-group">
              <label for="edit-episode-ordre">Ordre</label>
              <input
                type="number"
                id="edit-episode-ordre"
                v-model="editingEpisode.ordre"
                required
                class="form-input"
              />
            </div>
            <div class="form-group">
              <label for="edit-episode-statut">Statut</label>
              <select
                id="edit-episode-statut"
                v-model="editingEpisode.statutId"
                required
                class="form-select"
              >
                <option value="">Sélectionnez un statut</option>
                <option v-for="statut in statutsEpisode" :key="statut.idStatutEpisode" :value="statut.idStatutEpisode">
                  {{ statut.nomStatutsEpisode }}
                </option>
              </select>
            </div>
            <div v-if="editEpisodeError" class="error-message">
              {{ editEpisodeError }}
            </div>
            <div class="modal-actions">
              <button type="button" @click="closeEditEpisodeModal" class="cancel-btn">Annuler</button>
              <button type="submit" class="save-btn" :disabled="editEpisodeLoading">
                {{ editEpisodeLoading ? 'Sauvegarde...' : 'Sauvegarder' }}
              </button>
            </div>
          </form>
        </div>
      </div>

      <!-- Modale pour éditer la séquence -->
      <div v-if="showEditSequenceModal" class="modal-overlay">
        <div class="modal-content">
          <div class="modal-header">
            <h3>
              <i class="fas fa-edit icon"></i>
              Modifier la séquence
            </h3>
            <button @click="closeEditSequenceModal" class="close-btn"><i class="fas fa-times icon"></i></button>
          </div>
          <form @submit.prevent="saveEditedSequence" class="edit-form">
            <div class="form-group">
              <label for="edit-sequence-titre">Titre</label>
              <input
                type="text"
                id="edit-sequence-titre"
                v-model="editingSequence.titre"
                required
                class="form-input"
              />
            </div>
            <div class="form-group">
              <label for="edit-sequence-synopsis">Synopsis</label>
              <textarea
                id="edit-sequence-synopsis"
                v-model="editingSequence.synopsis"
                rows="4"
                class="form-textarea"
              ></textarea>
            </div>
            <div class="form-group">
              <label for="edit-sequence-ordre">Ordre</label>
              <input
                type="number"
                id="edit-sequence-ordre"
                v-model="editingSequence.ordre"
                required
                class="form-input"
              />
            </div>
            <div class="form-group">
              <label for="edit-sequence-statut">Statut</label>
              <select
                id="edit-sequence-statut"
                v-model="editingSequence.statutId"
                required
                class="form-select"
              >
                <option value="">Sélectionnez un statut</option>
                <option v-for="statut in statutsSequence" :key="statut.id" :value="statut.id">
                  {{ statut.nomStatutsSequence }}
                </option>
              </select>
            </div>
            <div v-if="editSequenceError" class="error-message">
              {{ editSequenceError }}
            </div>
            <div class="modal-actions">
              <button type="button" @click="closeEditSequenceModal" class="cancel-btn">Annuler</button>
              <button type="submit" class="save-btn" :disabled="editSequenceLoading">
                {{ editSequenceLoading ? 'Sauvegarde...' : 'Sauvegarder' }}
              </button>
            </div>
          </form>
        </div>
      </div>

      <!-- Modale pour éditer la scène -->
      <div v-if="showEditSceneModal" class="modal-overlay">
        <div class="modal-content">
          <div class="modal-header">
            <h3>
              <i class="fas fa-edit icon"></i>
              Modifier la scène
            </h3>
            <button @click="closeEditSceneModal" class="close-btn"><i class="fas fa-times icon"></i></button>
          </div>
          <form @submit.prevent="saveEditedScene" class="edit-form">
            <div class="form-group">
              <label for="edit-scene-titre">Titre</label>
              <input
                type="text"
                id="edit-scene-titre"
                v-model="editingScene.titre"
                required
                class="form-input"
              />
            </div>
            <div class="form-group">
              <label for="edit-scene-synopsis">Synopsis</label>
              <textarea
                id="edit-scene-synopsis"
                v-model="editingScene.synopsis"
                rows="4"
                class="form-textarea"
              ></textarea>
            </div>
            <div class="form-group">
              <label for="edit-scene-ordre">Ordre</label>
              <input
                type="number"
                id="edit-scene-ordre"
                v-model="editingScene.ordre"
                required
                class="form-input"
              />
            </div>
            <div class="form-group">
              <label for="edit-scene-statut">Statut</label>
              <select
                id="edit-scene-statut"
                v-model="editingScene.statutId"
                required
                class="form-select"
              >
                <option value="">Sélectionnez un statut</option>
                <option v-for="statut in statutsScene" :key="statut.id" :value="statut.id">
                  {{ statut.nomStatutsScene }}
                </option>
              </select>
            </div>
            <div v-if="editSceneError" class="error-message">
              {{ editSceneError }}
            </div>
            <div class="modal-actions">
              <button type="button" @click="closeEditSceneModal" class="cancel-btn">Annuler</button>
              <button type="submit" class="save-btn" :disabled="editSceneLoading">
                {{ editSceneLoading ? 'Sauvegarde...' : 'Sauvegarder' }}
              </button>
            </div>
          </form>
        </div>
      </div>

      <!-- Modale pour éditer le dialogue -->
      <div v-if="showEditDialogueModal" class="modal-overlay">
        <div class="modal-content">
          <div class="modal-header">
            <h3>
              <i class="fas fa-edit icon"></i>
              Modifier le dialogue
            </h3>
            <button @click="closeEditDialogueModal" class="close-btn"><i class="fas fa-times icon"></i></button>
          </div>
          <form @submit.prevent="saveEditedDialogue" class="edit-form">
            <div class="form-group">
              <label for="edit-dialogue-personnage">Personnage</label>
              <input
                type="text"
                id="edit-dialogue-personnage"
                v-model="editingDialogue.personnageNom"
                class="form-input"
                placeholder="Nom du personnage (vide pour Narrateur)"
              />
            </div>
            <div class="form-group">
              <label for="edit-dialogue-texte">Texte</label>
              <textarea
                id="edit-dialogue-texte"
                v-model="editingDialogue.texte"
                rows="4"
                class="form-textarea"
                required
              ></textarea>
            </div>
            <div class="form-group">
              <label for="edit-dialogue-observation">Observation</label>
              <textarea
                id="edit-dialogue-observation"
                v-model="editingDialogue.observation"
                rows="3"
                class="form-textarea"
                placeholder="Observation optionnelle"
              ></textarea>
            </div>
            <div v-if="editDialogueError" class="error-message">
              {{ editDialogueError }}
            </div>
            <div class="modal-actions">
              <button type="button" @click="closeEditDialogueModal" class="cancel-btn">Annuler</button>
              <button type="submit" class="save-btn" :disabled="editDialogueLoading">
                {{ editDialogueLoading ? 'Sauvegarde...' : 'Sauvegarder' }}
              </button>
            </div>
          </form>
        </div>
      </div>

      <!-- Modale pour commentaires de dialogue -->
      <div v-if="showDialogueCommentModal" class="modal-overlay">
        <div class="modal-content">
          <div class="modal-header">
            <h3>Commentaires du dialogue</h3>
            <button @click="closeDialogueCommentModal" class="close-btn"><i class="fas fa-times icon"></i></button>
          </div>
          <div class="add-comment">
            <textarea v-model="newDialogueComment" placeholder="Ajouter un commentaire..." rows="3"></textarea>
            <button @click="addDialogueComment" class="add-comment-btn">Ajouter</button>
          </div>
          <div class="comments-list">
            <div v-for="comment in dialogueComments" :key="comment.id" class="comment-item">
              <div class="comment-header">
                <span class="comment-author">{{ comment.utilisateurNom }}</span>
                <span class="comment-date">{{ formatDate(comment.creeLe) }}</span>
              </div>
              <div class="comment-content">
                {{ comment.contenu }}
              </div>
              <div class="comment-actions" v-if="comment.utilisateurId === user.id">
                <button @click="deleteDialogueComment(comment.id)" class="delete-comment-btn">Supprimer</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Modale pour ajouter un lieu/plateau -->
      <div v-if="showAddLieuModal" class="modal-overlay" @click="closeAddLieuModal">
        <div class="modal-content" @click.stop>
          <div class="modal-header">
            <h3>Ajouter un Lieu/Plateau à la scène: {{ selectedSceneForLieu?.titre }}</h3>
            <button @click="closeAddLieuModal" class="close-btn"><i class="fas fa-times icon"></i></button>
          </div>
          
          <form @submit.prevent="addSceneLieu" class="edit-form">
            <div class="form-group">
              <label for="lieu-select">Sélectionner un lieu existant</label>
              <select id="lieu-select" v-model="selectedLieuId" @change="loadAvailablePlateaux" class="form-select" required>
                <option value="">Choisir un lieu</option>
                <option v-if="availableLieux.length === 0" disabled>Aucun lieu disponible pour ce projet</option>
                <option v-for="lieu in availableLieux" :key="lieu.id" :value="lieu.id">
                  {{ lieu.nomLieu }} ({{ lieu.typeLieu }})
                </option>
              </select>
            </div>
            
            <div class="form-group" v-if="availablePlateaux.length > 0">
              <label for="plateau-select">Sélectionner un plateau existant (optionnel)</label>
              <select id="plateau-select" v-model="selectedPlateauId" class="form-select">
                <option value="">Aucun plateau</option>
                <option v-for="plateau in availablePlateaux" :key="plateau.id" :value="plateau.id">
                  {{ plateau.nom }} ({{ plateau.typePlateau }})
                </option>
              </select>
            </div>
            
            <div class="form-group">
              <label for="description-utilisation">Description d'utilisation</label>
              <textarea 
                id="description-utilisation" 
                v-model="descriptionUtilisation" 
                rows="3" 
                class="form-textarea" 
                placeholder="Description de l'utilisation de ce lieu/plateau dans la scène..."
              ></textarea>
            </div>
            
            <div v-if="addLieuError" class="error-message">
              {{ addLieuError }}
            </div>
            
            <div class="modal-actions">
              <button type="button" @click="closeAddLieuModal" class="cancel-btn">Annuler</button>
              <button type="submit" class="save-btn" :disabled="addLieuLoading">
                {{ addLieuLoading ? 'Ajout en cours...' : 'Ajouter' }}
              </button>
            </div>
          </form>
          
          <!-- Liste des lieux déjà associés à cette scène -->
          <div class="associated-lieux" v-if="sceneLieus.length > 0">
            <h4>Lieux déjà associés:</h4>
            <div v-for="sceneLieu in sceneLieus" :key="sceneLieu.id" class="scene-lieu-item">
              <div class="scene-lieu-info">
                <strong>{{ sceneLieu.lieuNom }}</strong>
                <span v-if="sceneLieu.plateauNom"> - Plateau: {{ sceneLieu.plateauNom }}</span>
                - {{ sceneLieu.descriptionUtilisation || 'Aucune description' }}
              </div>
              <button @click="removeLieuFromScene(sceneLieu.id)" class="delete-btn" title="Supprimer">
                🗑️
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useEcranTravailStore } from '../stores/ecranTravailStore';
import { computed, onMounted, ref, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import axios from 'axios';
import '../assets/css/ecran_travail.css';

const route = useRoute();
const router = useRouter();
const store = useEcranTravailStore();

// Données pour les commentaires
const user = ref(JSON.parse(localStorage.getItem('user')) || null);
const showSequenceCommentSection = ref(false);
const newSequenceComment = ref('');
const sequenceComments = ref([]);
const sequenceCommentCount = ref(0);

const showSceneCommentModal = ref(false);
const selectedScene = ref(null);
const newSceneComment = ref('');
const sceneComments = ref([]);
const sceneCommentCounts = ref({});

const showDialogueCommentModal = ref(false);
const selectedDialogue = ref(null);
const newDialogueComment = ref('');
const dialogueComments = ref([]);
const dialogueCommentCounts = ref({});

// Données pour la modale d'ajout de lieu
const showAddLieuModal = ref(false);
const selectedSceneForLieu = ref(null);
const selectedLieuId = ref(null);
const selectedPlateauId = ref(null);
const descriptionUtilisation = ref('');
const availableLieux = ref([]);
const availablePlateaux = ref([]);
const sceneLieus = ref([]);
const addLieuError = ref('');
const addLieuLoading = ref(false);

// Données pour l'édition des épisodes
const showEditEpisodeModal = ref(false);
const editingEpisode = ref({
  id: null,
  titre: '',
  synopsis: '',
  ordre: null,
  statutId: null
});
const statutsEpisode = ref([]);
const editEpisodeError = ref('');
const editEpisodeLoading = ref(false);

// Données pour l'édition des séquences
const showEditSequenceModal = ref(false);
const editingSequence = ref({
  id: null,
  titre: '',
  synopsis: '',
  ordre: null,
  statutId: null
});
const statutsSequence = ref([]);
const editSequenceError = ref('');
const editSequenceLoading = ref(false);

// Données pour l'édition des scènes
const showEditSceneModal = ref(false);
const editingScene = ref({
  id: null,
  titre: '',
  synopsis: '',
  ordre: null,
  statutId: null
});
const statutsScene = ref([]);
const editSceneError = ref('');
const editSceneLoading = ref(false);

// Données pour l'édition des dialogues
const showEditDialogueModal = ref(false);
const editingDialogue = ref({
  id: null,
  personnageNom: '',
  texte: '',
  observation: ''
});
const editDialogueError = ref('');
const editDialogueLoading = ref(false);

// Projet ID
const projetId = ref(route.params.idProjet || '1');

// Variable pour suivre l'épisode et la séquence nouvellement créés
const newlyCreatedEpisodeId = ref(null);
const newlyCreatedSequenceId = ref(null);

// Propriétés calculées
const episodes = computed(() => store.episodes);
const sequences = computed(() => store.sequences);

onMounted(async () => {
  const projetIdLocal = route.params.idProjet || '1';
  projetId.value = projetIdLocal;
  await store.fetchEpisodes(projetIdLocal);
  if (store.currentSequence) {
    await loadSequenceCommentCount();
    await loadSceneCommentCounts();
    await loadDialogueCommentCounts();
    await loadAvailableLieux();
  }
  await Promise.all([
    loadStatutsEpisode(),
    loadStatutsSequence(),
    loadStatutsScene()
  ]);
  const episodeId = route.query.episodeId;
  const sequenceId = route.query.sequenceId;

  if (episodeId) {
    await store.selectEpisodeById(episodeId);
  }

  if (sequenceId) {
    await store.selectSequenceById(sequenceId);
  }
});

onMounted(async () => {
  projetId.value = route.params.projetId;
  if (!projetId.value) {
    console.error('ID du projet non trouvé dans les params de route !');
    return;
  }

  await store.fetchEpisodes(projetId.value);

  const episodeId = route.query.episodeId ? parseInt(route.query.episodeId) : null;
  const sequenceId = route.query.sequenceId ? parseInt(route.query.sequenceId) : null;

  if (episodeId) {
    await store.selectEpisodeById(episodeId);
  }
  if (sequenceId) {
    await store.selectSequenceById(sequenceId);
  }

  // Optionnel : Nettoie les query params après restauration pour une URL propre
  router.replace({ query: null });
});

// Watchers
watch(
  () => route.query.episodeId,
  async (newId) => {
    if (newId) {
      await store.selectEpisodeById(newId);
    }
  },
  { immediate: true }
);

watch(() => route.params.idProjet, async (newProjetId) => {
  if (newProjetId) {
    projetId.value = newProjetId;
    await loadAvailableLieux();
  }
});

watch(() => store.currentSequence, async (newSequence) => {
  if (newSequence) {
    await loadSequenceCommentCount();
    await loadSceneCommentCounts();
    await loadDialogueCommentCounts();
  }
});

// Charger les statuts
const loadStatutsEpisode = async () => {
  try {
    const response = await axios.get('/api/statuts-episode');
    statutsEpisode.value = response.data;
  } catch (error) {
    console.error('Erreur lors du chargement des statuts d\'épisode:', error);
  }
};

const loadStatutsSequence = async () => {
  try {
    const response = await axios.get('/api/statuts-sequence');
    statutsSequence.value = response.data;
  } catch (error) {
    console.error('Erreur lors du chargement des statuts de séquence:', error);
  }
};

const loadStatutsScene = async () => {
  try {
    const response = await axios.get('/api/statuts-scene');
    statutsScene.value = response.data;
  } catch (error) {
    console.error('Erreur lors du chargement des statuts de scène:', error);
  }
};

// Charger les lieux et plateaux disponibles
const loadAvailableLieux = async () => {
  try {
    if (!projetId.value) {
      const episodeResponse = await axios.get(`/api/episodes/${store.currentEpisode?.idEpisode}`);
      projetId.value = episodeResponse.data.projetId || '1';
    }
    const response = await axios.get(`/api/lieux/projets/${projetId.value}`);
    availableLieux.value = response.data;
  } catch (error) {
    console.error('Erreur lors du chargement des lieux:', error);
    availableLieux.value = [];
  }
};

const loadAvailablePlateaux = async () => {
  if (!selectedLieuId.value) {
    availablePlateaux.value = [];
    return;
  }
  
  try {
    const response = await axios.get(`/api/scene-lieux/lieux/${selectedLieuId.value}/plateaux`);
    availablePlateaux.value = response.data;
  } catch (error) {
    console.error('Erreur lors du chargement des plateaux:', error);
    availablePlateaux.value = [];
  }
};

// Helpers
const capitalize = (str) => str.charAt(0).toUpperCase() + str.slice(1);

const getStatuts = (type) => {
  if (type === 'episode') return statutsEpisode.value;
  if (type === 'sequence') return statutsSequence.value;
  if (type === 'scene') return statutsScene.value;
  return [];
};

const getNomField = (type) => `nomStatuts${capitalize(type)}`;

const getIdField = (type) => {
  if (type === 'episode') return 'idStatutEpisode';
  return 'id';
};

const getStatutIdByNom = (type, nom) => {
  const statuts = getStatuts(type);
  const nomField = getNomField(type);
  const statut = statuts.find(s => s[nomField] === nom);
  const idField = getIdField(type);
  return statut ? statut[idField] : null;
};

const getStatutNomById = (type, id) => {
  const statuts = getStatuts(type);
  const idField = getIdField(type);
  const nomField = getNomField(type);
  const statut = statuts.find(s => s[idField] === id);
  return statut ? statut[nomField] : '';
};

// Méthodes pour l'édition
const startEditEpisode = () => {
  if (!store.currentEpisode) return;
  editingEpisode.value = {
    id: store.currentEpisode.idEpisode,
    titre: store.currentEpisode.titre,
    synopsis: store.currentEpisode.synopsis || '',
    ordre: store.currentEpisode.ordre,
    statutId: getStatutIdByNom('episode', store.currentEpisode.statutNom)
  };
  editEpisodeError.value = '';
  showEditEpisodeModal.value = true;
};

const saveEditedEpisode = async () => {
  editEpisodeLoading.value = true;
  editEpisodeError.value = '';

  try {
    const url = `/api/episodes/${editingEpisode.value.id}`;
    const updateData = {
      titre: editingEpisode.value.titre,
      synopsis: editingEpisode.value.synopsis,
      ordre: parseInt(editingEpisode.value.ordre),
      statutId: editingEpisode.value.statutId
    };
    const response = await axios.put(url, updateData);
    if (response.status === 200) {
      store.currentEpisode.titre = editingEpisode.value.titre;
      store.currentEpisode.synopsis = editingEpisode.value.synopsis;
      store.currentEpisode.ordre = editingEpisode.value.ordre;
      store.currentEpisode.statutNom = getStatutNomById('episode', editingEpisode.value.statutId);
      const episodeIndex = store.episodes.findIndex(e => e.idEpisode === editingEpisode.value.id);
      if (episodeIndex !== -1) {
        store.episodes[episodeIndex] = { ...store.episodes[episodeIndex], ...editingEpisode.value };
      }
      closeEditEpisodeModal();
    }
  } catch (error) {
    console.error('Erreur lors de la mise à jour de l\'épisode:', error);
    editEpisodeError.value = error.response?.data?.message || 'Erreur lors de la mise à jour de l\'épisode';
  } finally {
    editEpisodeLoading.value = false;
  }
};

const closeEditEpisodeModal = () => {
  showEditEpisodeModal.value = false;
  editingEpisode.value = { id: null, titre: '', synopsis: '', ordre: null, statutId: null };
  editEpisodeError.value = '';
};

const startEditSequence = (sequence) => {
  editingSequence.value = {
    id: sequence.idSequence,
    titre: sequence.titre,
    synopsis: sequence.synopsis || '',
    ordre: sequence.ordre,
    statutId: getStatutIdByNom('sequence', sequence.statutNom)
  };
  editSequenceError.value = '';
  showEditSequenceModal.value = true;
};

const saveEditedSequence = async () => {
  editSequenceLoading.value = true;
  editSequenceError.value = '';

  try {
    const url = `/api/sequences/${editingSequence.value.id}`;
    const updateData = {
      titre: editingSequence.value.titre,
      synopsis: editingSequence.value.synopsis,
      ordre: parseInt(editingSequence.value.ordre),
      statutId: editingSequence.value.statutId
    };
    const response = await axios.put(url, updateData);
    if (response.status === 200) {
      store.currentSequence.titre = editingSequence.value.titre;
      store.currentSequence.synopsis = editingSequence.value.synopsis;
      store.currentSequence.ordre = editingSequence.value.ordre;
      store.currentSequence.statutNom = getStatutNomById('sequence', editingSequence.value.statutId);
      await store.fetchSequences(store.currentEpisode.idEpisode);
      closeEditSequenceModal();
    }
  } catch (error) {
    console.error('Erreur lors de la mise à jour de la séquence:', error);
    editSequenceError.value = error.response?.data?.message || 'Erreur lors de la mise à jour de la séquence';
  } finally {
    editSequenceLoading.value = false;
  }
};

const closeEditSequenceModal = () => {
  showEditSequenceModal.value = false;
  editingSequence.value = { id: null, titre: '', synopsis: '', ordre: null, statutId: null };
  editSequenceError.value = '';
};

const startEditScene = (scene) => {
  editingScene.value = {
    id: scene.idScene,
    titre: scene.titre,
    synopsis: scene.synopsis || '',
    ordre: scene.ordre,
    statutId: getStatutIdByNom('scene', scene.statutNom)
  };
  editSceneError.value = '';
  showEditSceneModal.value = true;
};

const saveEditedScene = async () => {
  editSceneLoading.value = true;
  editSceneError.value = '';

  try {
    const url = `/api/scenes/${editingScene.value.id}`;
    const updateData = {
      titre: editingScene.value.titre,
      synopsis: editingScene.value.synopsis,
      ordre: parseInt(editingScene.value.ordre),
      statutId: editingScene.value.statutId
    };
    const response = await axios.put(url, updateData);
    if (response.status === 200) {
      const sceneIndex = store.currentSequence.scenes.findIndex(s => s.idScene === editingScene.value.id);
      if (sceneIndex !== -1) {
        store.currentSequence.scenes[sceneIndex] = {
          ...store.currentSequence.scenes[sceneIndex],
          titre: editingScene.value.titre,
          synopsis: editingScene.value.synopsis,
          ordre: editingScene.value.ordre,
          statutNom: getStatutNomById('scene', editingScene.value.statutId)
        };
      }
      await store.fetchSequenceDetails(store.currentSequence.idSequence);
      closeEditSceneModal();
    }
  } catch (error) {
    console.error('Erreur lors de la mise à jour de la scène:', error);
    editSceneError.value = error.response?.data?.message || 'Erreur lors de la mise à jour de la scène';
  } finally {
    editSceneLoading.value = false;
  }
};

const closeEditSceneModal = () => {
  showEditSceneModal.value = false;
  editingScene.value = { id: null, titre: '', synopsis: '', ordre: null, statutId: null };
  editSceneError.value = '';
};

const startEditDialogue = (dialogue) => {
  editingDialogue.value = {
    id: dialogue.id,
    personnageNom: dialogue.personnageNom || '',
    texte: dialogue.texte,
    observation: dialogue.observation || ''
  };
  editDialogueError.value = '';
  showEditDialogueModal.value = true;
};

const saveEditedDialogue = async () => {
  if (!editingDialogue.value.texte.trim()) {
    editDialogueError.value = 'Le texte du dialogue est requis.';
    return;
  }

  editDialogueLoading.value = true;
  editDialogueError.value = '';

  try {
    const url = `/api/dialogues/${editingDialogue.value.id}`;
    const updateData = {
      personnageNom: editingDialogue.value.personnageNom || null,
      texte: editingDialogue.value.texte,
      observation: editingDialogue.value.observation || null
    };
    const response = await axios.put(url, updateData);
    if (response.status === 200) {
      await store.fetchSequenceDetails(store.currentSequence.idSequence);
      closeEditDialogueModal();
    }
  } catch (error) {
    console.error('Erreur lors de la mise à jour du dialogue:', error);
    editDialogueError.value = error.response?.data?.message || 'Erreur lors de la mise à jour du dialogue';
  } finally {
    editDialogueLoading.value = false;
  }
};

const closeEditDialogueModal = () => {
  showEditDialogueModal.value = false;
  editingDialogue.value = { id: null, personnageNom: '', texte: '', observation: '' };
  editDialogueError.value = '';
};

// Méthodes pour la navigation
const goToNextPage = () => store.goToNextPage();
const goToPrevPage = () => store.goToPrevPage();
const retryFetch = () => store.fetchEpisodes(projetId.value);

const selectEpisode = async (episodeId) => {
  try {
    await store.selectEpisodeById(episodeId);
    router.push({ query: { ...route.query, episodeId } });
  } catch (error) {
    console.error('Erreur lors de la sélection de l\'épisode:', error);
  }
};

// const selectSequence = async (sequenceId) => {
//   try {
//     await store.selectSequenceById(sequenceId);
//     router.push({ query: { ...route.query, sequenceId } });
//   } catch (error) {
//     console.error('Erreur lors de la sélection de la séquence:', error);
//   }
// };

const selectSequence = async (sequenceId) => {
  await store.selectSequenceById(sequenceId);
  // Si newlyCreatedSequenceId n'est pas défini, supprimez cette ligne ou ajoutez const newlyCreatedSequenceId = ref(null);
  newlyCreatedSequenceId.value = null;
};

// Méthodes pour l'ajout
const goToAddEpisode = async () => {
  if (!projetId.value) {
    console.error('ID du projet non trouvé !');
    alert('ID du projet manquant. Veuillez réessayer.');
    return;
  }
  try {
    const response = await axios.post(`/api/episodes`, {
      projetId: projetId.value,
      titre: 'Nouvel Épisode',
      ordre: store.episodes.length + 1,
      synopsis: '',
      statutId: getStatutIdByNom('episode', 'Brouillon')
    });
    if (response.status === 201) {
      const newEpisodeId = response.data.idEpisode;
      await store.fetchEpisodes(projetId.value);
      newlyCreatedEpisodeId.value = newEpisodeId;
      await selectEpisode(newEpisodeId);
      setTimeout(() => {
        newlyCreatedEpisodeId.value = null;
      }, 5000);
    }
  } catch (error) {
    console.error('Erreur lors de la création de l\'épisode:', error);
  }
  router.push(`/projet/${projetId.value}/add-episode-ecran-travail`);
};

const goToAddSequence = async () => {
  if (!store.currentEpisode?.idEpisode) {
    console.error('ID de l\'épisode non trouvé !');
    alert('ID de l\'épisode manquant. Veuillez réessayer.');
    return;
  }
  try {
    const response = await axios.post(`/api/sequences`, {
      episodeId: store.currentEpisode.idEpisode,
      titre: 'Nouvelle Séquence',
      ordre: store.sequences.length + 1,
      synopsis: '',
      statutId: getStatutIdByNom('sequence', 'Brouillon')
    });
    if (response.status === 201) { 
      const newSequenceId = response.data.idSequence;
      await store.fetchSequences(store.currentEpisode.idEpisode);
      newlyCreatedSequenceId.value = newSequenceId;
      await selectSequence(newSequenceId);
      setTimeout(() => {
        newlyCreatedSequenceId.value = null;
      }, 5000);
    }
  } catch (error) {
    console.error('Erreur lors de la création de la séquence:', error);
  }
  router.push(`/episode/${store.currentEpisode?.idEpisode}/add-sequence-ecran-travail`);
};

const goToAddScene = () => {
  router.push(`/sequence/${store.currentSequence?.idSequence}/add-scene-ecran-travail`);
};

const goToAddDialogue = (sceneId) => {
  router.push(`/scene/${sceneId}/add-dialogue-scene-ecran-travail`);
};

const goToAddComedien = (sceneId) => {
  router.push(`/scene/${sceneId}/add-comedien-ecran-travail`);
};

const goToAddLieu = () => {
  if (!projetId.value) {
    console.error('ID du projet non trouvé !');
    alert('ID du projet manquant. Veuillez réessayer.');
    return;
  }
  router.push(`/projet/${projetId.value}/add-lieu-scene-ecran-travail`);
};


const goToAddPlateau = () => {
  if (!projetId.value) {
    console.error('ID du projet non trouvé !');
    alert('ID du projet manquant. Veuillez réessayer.');
    return;
  }
  router.push(`/projet/${projetId.value}/add-plateau-scene`);
};

const goToAddPersonnage = () => {
  if (!projetId.value) {
    console.error('ID du projet non trouvé !');
    alert('ID du projet manquant. Veuillez réessayer.');
    return;
  }
  router.push(`/projet/${projetId.value}/add-personnage-ecran-travail`);
};

// Méthodes pour la modale d'ajout de lieu
const openAddLieuModal = async (scene) => {
  selectedSceneForLieu.value = scene;
  await loadAvailableLieux();
  await loadSceneLieus(scene.idScene);
  addLieuError.value = '';
  selectedLieuId.value = null;
  selectedPlateauId.value = null;
  descriptionUtilisation.value = '';
  availablePlateaux.value = [];
  showAddLieuModal.value = true;
};

const closeAddLieuModal = () => {
  showAddLieuModal.value = false;
  selectedSceneForLieu.value = null;
  selectedLieuId.value = null;
  selectedPlateauId.value = null;
  descriptionUtilisation.value = '';
  sceneLieus.value = [];
  addLieuError.value = '';
};

const loadSceneLieus = async (sceneId) => {
  try {
    const response = await axios.get(`/api/scene-lieux/scenes/${sceneId}`);
    sceneLieus.value = response.data;
  } catch (error) {
    console.error('Erreur lors du chargement des lieux de la scène:', error);
    sceneLieus.value = [];
  }
};

const addSceneLieu = async () => {
  if (!selectedLieuId.value) {
    addLieuError.value = 'Veuillez sélectionner un lieu.';
    return;
  }

  addLieuLoading.value = true;
  addLieuError.value = '';

  try {
    const lieuData = {
      sceneId: selectedSceneForLieu.value.idScene,
      lieuId: selectedLieuId.value,
      plateauId: selectedPlateauId.value || null,
      descriptionUtilisation: descriptionUtilisation.value
    };

    const response = await axios.post('/api/scene-lieux', lieuData);
    
    if (response.status === 201) {
      await loadSceneLieus(selectedSceneForLieu.value.idScene);
      await store.fetchSequenceDetails(store.currentSequence.idSequence);
      
      selectedLieuId.value = null;
      selectedPlateauId.value = null;
      descriptionUtilisation.value = '';
      availablePlateaux.value = [];
    }
  } catch (error) {
    console.error('Erreur lors de l\'ajout du lieu/plateau:', error);
    addLieuError.value = error.response?.data?.message || 'Erreur lors de l\'ajout du lieu/plateau';
  } finally {
    addLieuLoading.value = false;
  }
};

const removeLieuFromScene = async (sceneLieuId) => {
  if (confirm('Êtes-vous sûr de vouloir supprimer ce lieu/plateau de la scène ?')) {
    try {
      await axios.delete(`/api/scene-lieux/${sceneLieuId}`);
      await loadSceneLieus(selectedSceneForLieu.value.idScene);
      await store.fetchSequenceDetails(store.currentSequence.idSequence);
    } catch (error) {
      console.error('Erreur lors de la suppression du lieu/plateau:', error);
      alert('Erreur lors de la suppression du lieu/plateau');
    }
  }
};

// Méthodes pour les commentaires
const toggleSequenceCommentSection = async () => {
  showSequenceCommentSection.value = !showSequenceCommentSection.value;
  if (showSequenceCommentSection.value) {
    await loadSequenceComments();
    await loadSequenceCommentCount();
  }
};

const loadSequenceComments = async () => {
  try {
    const response = await axios.get(`/api/sequence-commentaires/sequence/${store.currentSequence.idSequence}`);
    sequenceComments.value = response.data;
  } catch (error) {
    console.error('Erreur lors du chargement des commentaires de séquence:', error);
  }
};

const loadSequenceCommentCount = async () => {
  if (!store.currentSequence) return;
  try {
    const response = await axios.get(`/api/sequence-commentaires/sequence/${store.currentSequence.idSequence}/count`);
    sequenceCommentCount.value = response.data;
  } catch (error) {
    console.error('Erreur lors du chargement du nombre de commentaires:', error);
  }
};

const addSequenceComment = async () => {
  if (!newSequenceComment.value.trim()) return;
  try {
    await axios.post('/api/sequence-commentaires', {
      contenu: newSequenceComment.value,
      sequenceId: store.currentSequence.idSequence
    }, {
      headers: {
        'X-User-Id': user.value.id
      }
    });
    newSequenceComment.value = '';
    await loadSequenceComments();
    await loadSequenceCommentCount();
  } catch (error) {
    console.error('Erreur lors de l\'ajout du commentaire:', error);
    alert('Erreur lors de l\'ajout du commentaire');
  }
};

const deleteSequenceComment = async (commentId) => {
  if (confirm('Êtes-vous sûr de vouloir supprimer ce commentaire ?')) {
    try {
      await axios.delete(`/api/sequence-commentaires/${commentId}`);
      await loadSequenceComments();
      await loadSequenceCommentCount();
    } catch (error) {
      console.error('Erreur lors de la suppression du commentaire:', error);
    }
  }
};

const toggleSceneCommentSection = async (scene) => {
  selectedScene.value = scene;
  showSceneCommentModal.value = true;
  await loadSceneComments(scene.idScene);
};

const closeSceneCommentModal = () => {
  showSceneCommentModal.value = false;
  selectedScene.value = null;
  sceneComments.value = [];
};

const loadSceneComments = async (sceneId) => {
  try {
    const response = await axios.get(`/api/scene-commentaires/scene/${sceneId}`);
    sceneComments.value = response.data;
  } catch (error) {
    console.error('Erreur lors du chargement des commentaires de scène:', error);
  }
};

const getSceneCommentCount = (sceneId) => {
  return sceneCommentCounts.value[sceneId] || 0;
};

const loadSceneCommentCounts = async () => {
  if (!store.currentSequence?.scenes) return;
  for (const scene of store.currentSequence.scenes) {
    try {
      const response = await axios.get(`/api/scene-commentaires/scene/${scene.idScene}/count`);
      sceneCommentCounts.value[scene.idScene] = response.data;
    } catch (error) {
      console.error('Erreur lors du chargement du nombre de commentaires pour la scène:', error);
      sceneCommentCounts.value[scene.idScene] = 0;
    }
  }
};

const addSceneComment = async () => {
  if (!newSceneComment.value.trim() || !selectedScene.value) return;
  try {
    await axios.post('/api/scene-commentaires', {
      contenu: newSceneComment.value,
      sceneId: selectedScene.value.idScene
    }, {
      headers: {
        'X-User-Id': user.value.id
      }
    });
    newSceneComment.value = '';
    await loadSceneComments(selectedScene.value.idScene);
    await loadSceneCommentCounts();
  } catch (error) {
    console.error('Erreur lors de l\'ajout du commentaire:', error);
    alert('Erreur lors de l\'ajout du commentaire');
  }
};

const deleteSceneComment = async (commentId) => {
  if (confirm('Êtes-vous sûr de vouloir supprimer ce commentaire ?')) {
    try {
      await axios.delete(`/api/scene-commentaires/${commentId}`);
      await loadSceneComments(selectedScene.value.idScene);
      await loadSceneCommentCounts();
    } catch (error) {
      console.error('Erreur lors de la suppression du commentaire:', error);
    }
  }
};

const toggleDialogueCommentSection = async (dialogue) => {
  selectedDialogue.value = dialogue;
  showDialogueCommentModal.value = true;
  await loadDialogueComments(dialogue.id);
};

const closeDialogueCommentModal = () => {
  showDialogueCommentModal.value = false;
  selectedDialogue.value = null;
  dialogueComments.value = [];
};

const loadDialogueComments = async (dialogueId) => {
  try {
    const response = await axios.get(`/api/dialogues/commentaires/dialogue/${dialogueId}`);
    dialogueComments.value = response.data;
  } catch (error) {
    console.error('Erreur lors du chargement des commentaires de dialogue:', error);
  }
};

const getDialogueCommentCount = (dialogueId) => {
  return dialogueCommentCounts.value[dialogueId] || 0;
};

const loadDialogueCommentCounts = async () => {
  if (!store.currentSequence?.scenes) return;
  for (const scene of store.currentSequence.scenes) {
    if (scene.dialogues && scene.dialogues.length > 0) {
      for (const dialogue of scene.dialogues) {
        try {
          const response = await axios.get(`/api/dialogues/commentaires/dialogue/${dialogue.id}/count`);
          dialogueCommentCounts.value[dialogue.id] = response.data;
        } catch (error) {
          console.error('Erreur lors du chargement du nombre de commentaires pour le dialogue:', error);
          dialogueCommentCounts.value[dialogue.id] = 0;
        }
      }
    }
  }
};

const addDialogueComment = async () => {
  if (!newDialogueComment.value.trim() || !selectedDialogue.value) return;
  try {
    await axios.post('/api/dialogues/commentaires', {
      contenu: newDialogueComment.value,
      dialogueId: selectedDialogue.value.id
    }, {
      headers: {
        'X-User-Id': user.value.id
      }
    });
    newDialogueComment.value = '';
    await loadDialogueComments(selectedDialogue.value.id);
    await loadDialogueCommentCounts();
  } catch (error) {
    console.error('Erreur lors de l\'ajout du commentaire:', error);
    alert('Erreur lors de l\'ajout du commentaire');
  }
};

const deleteDialogueComment = async (commentId) => {
  if (confirm('Êtes-vous sûr de vouloir supprimer ce commentaire ?')) {
    try {
      await axios.delete(`/api/dialogues/commentaires/${commentId}`);
      await loadDialogueComments(selectedDialogue.value.id);
      await loadDialogueCommentCounts();
    } catch (error) {
      console.error('Erreur lors de la suppression du commentaire:', error);
    }
  }
};

// Méthodes de suppression
const deleteSequence = async (sequenceId) => {
  if (confirm('Êtes-vous sûr de vouloir supprimer cette séquence ?')) {
    try {
      await axios.delete(`/api/sequences/${sequenceId}`);
      await store.fetchSequences(store.currentEpisode.idEpisode);
    } catch (error) {
      console.error('Erreur lors de la suppression de la séquence:', error);
      alert('Erreur lors de la suppression de la séquence');
    }
  }
};

const deleteScene = async (sceneId) => {
  if (confirm('Êtes-vous sûr de vouloir supprimer cette scène ?')) {
    try {
      await axios.delete(`/api/scenes/${sceneId}`);
      await store.fetchSequenceDetails(store.currentSequence.idSequence);
    } catch (error) {
      console.error('Erreur lors de la suppression de la scène:', error);
      alert('Erreur lors de la suppression de la scène');
    }
  }
};

const deleteDialogue = async (dialogueId) => {
  if (confirm('Êtes-vous sûr de vouloir supprimer ce dialogue ?')) {
    try {
      await axios.delete(`/api/dialogues/${dialogueId}`);
      await store.fetchSequenceDetails(store.currentSequence.idSequence);
    } catch (error) {
      console.error('Erreur lors de la suppression du dialogue:', error);
      alert('Erreur lors de la suppression du dialogue');
    }
  }
};

const deleteSceneLieu = async (sceneLieuId) => {
  if (confirm('Êtes-vous sûr de vouloir supprimer ce lieu/plateau ?')) {
    try {
      await axios.delete(`/api/scene-lieux/${sceneLieuId}`);
      await store.fetchSequenceDetails(store.currentSequence.idSequence);
    } catch (error) {
      console.error('Erreur lors de la suppression du lieu/plateau:', error);
      alert('Erreur lors de la suppression du lieu/plateau');
    }
  }
};

// Méthode utilitaire pour formater les dates
const formatDate = (date) => {
  return new Date(date).toLocaleString();
};

// Propriétés calculées
const currentEpisode = computed(() => store.currentEpisode);
const currentSequence = computed(() => store.currentSequence);
const error = computed(() => store.error);
const isLoading = computed(() => store.isLoading);
const hasNext = computed(() => store.hasNext);
const hasPrev = computed(() => store.hasPrev);
</script>

<style>
.sequence-navigation {
  display: flex;
  gap: 5px;
  margin: 10px 0;
  justify-content: center;
  align-items: center;
}

.sequence-number {
  cursor: pointer;
  padding: 8px 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  background-color: #f9f9f9;
  font-size: 16px;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
}

.sequence-number:hover {
  background-color: #e0e0e0;
}

.sequence-number.active {
  background-color: #007bff;
  color: white;
  border-color: #007bff;
}

.new-sequence {
  position: relative;
}

.blinking-icon {
  position: absolute;
  top: -5px;
  right: -5px;
  font-size: 12px;
  animation: blink 1s infinite;
}

.separator {
  margin: 0 5px;
  color: #000;
  font-weight: bold;
}

@keyframes blink {
  0% { opacity: 1; }
  50% { opacity: 0; }
  100% { opacity: 1; }
}
</style>
