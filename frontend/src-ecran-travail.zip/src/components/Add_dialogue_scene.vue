<template>
  <div class="creation-dialogue-container">

    <!-- Contenu principal -->
    <main class="main-content">
      <div class="page-header">
        <button @click="goBack" class="back-btn">← Retour</button>
        <h2>Gestion des Dialogues</h2>
      </div>

      <!-- Formulaire de création -->
      <div class="creation-form">
        <h3>{{ isEditing ? 'Modifier' : 'Ajouter' }} un dialogue</h3>
        <form @submit.prevent="submitForm">
          <div class="form-group">
            <label>Scène</label>
            <input 
              :value="sceneTitle" 
              type="text" 
              disabled 
              placeholder="Nom de la scène" 
            />
            <input type="hidden" v-model="formData.sceneId" />
          </div>
          
          <div class="form-group">
            <label>Personnage</label>
            <select v-model="formData.personnageId">
              <option :value="null">Narration (sans personnage)</option>
              <option v-for="personnage in personnages" :key="personnage.id" :value="personnage.id">
                {{ personnage.nom }} ({{ personnage.projetTitre }})
              </option>
            </select>
          </div>
          
          <div class="form-group">
            <label>Texte</label>
            <textarea v-model="formData.texte" rows="4" placeholder="Entrez le texte du dialogue..."></textarea>
          </div>
          
          <div class="form-group">
            <label>Ordre</label>
            <input v-model="formData.ordre" type="number" min="1" required>
          </div>
          
          <div class="form-group">
            <label>Observation</label>
            <textarea v-model="formData.observation" rows="3" placeholder="Notes ou observations..."></textarea>
          </div>
          
          <button type="submit" class="submit-btn">{{ isEditing ? 'Modifier' : 'Ajouter' }} le dialogue</button>
          <button v-if="isEditing" type="button" @click="resetForm" class="cancel-btn">Annuler</button>
        </form>
      </div>
      
    </main>
  </div>
</template>

<script>
import axios from 'axios';
import '../assets/css/dialogue.css';

export default {
  name: 'CreationDialogue',
  data() {
    return {
      user: JSON.parse(localStorage.getItem('user')) || null,
      showProfileMenu: false,
      formData: {
        sceneId: '',
        personnageId: null,
        texte: '',
        ordre: 1,
        observation: ''
      },
      sceneTitle: '',
      scene: {}, // Ajout : stocker les détails complets de la scène (incluant sequence et episode)
      isEditing: false,
      editingId: null,
      scenes: [],
      personnages: [],
      searchTerm: '',
      filterSceneId: '',
      filterPersonnageId: '',
      loading: true,
      dialogues: [],
      newDialogueId: null // Ajout : similaire à newSequenceId pour flagger la création
    };
  },
  computed: {
    userInitials() {
      if (!this.user?.nom) return '';
      const names = this.user.nom.split(' ');
      return names.map(n => n[0]).join('').toUpperCase();
    },
    filteredDialogues() {
      return this.dialogues.filter(dialogue => {
        const matchesSearch = dialogue.texte.toLowerCase().includes(this.searchTerm.toLowerCase());
        const matchesScene = !this.filterSceneId || dialogue.sceneId === parseInt(this.filterSceneId);
        const matchesPersonnage = !this.filterPersonnageId || 
          (this.filterPersonnageId === 'null' && !dialogue.personnageId) || 
          dialogue.personnageId === parseInt(this.filterPersonnageId);
        return matchesSearch && matchesScene && matchesPersonnage;
      });
    },
    sceneId() {
      return this.$route.params.sceneId;
    }
  },
  async created() {
    await Promise.all([
      this.loadPersonnages(),
      this.loadDialogues()
    ]);
    this.loading = false;
    document.addEventListener('click', this.handleClickOutside);

    if (this.sceneId) {
      await this.loadSceneDetails();
      this.formData.sceneId = this.sceneId;
    }
  },
  beforeDestroy() {
    document.removeEventListener('click', this.handleClickOutside);
  },
  methods: {
    async loadSceneDetails() {
      try {
        const response = await axios.get(`/api/scenes/${this.sceneId}`);
        this.scene = response.data; // Ajout : stocker tous les détails (assume que response.data inclut titre, sequenceId, episodeId, projetId ou nested)
        this.sceneTitle = this.scene.titre;

        // Si l'API ne retourne pas directement sequence/episode/projet, chain des fetches supplémentaires
        if (!this.scene.sequenceId) {
          // Exemple : fetch sequence si needed (adapte selon ton API)
          const sequenceResponse = await axios.get(`/api/sequences/${this.scene.sequenceId}`); // Assume scene a sequenceId
          this.scene.sequence = sequenceResponse.data;
          const episodeResponse = await axios.get(`/api/episodes/${this.scene.sequence.episodeId}`);
          this.scene.episode = episodeResponse.data;
          this.scene.projetId = this.scene.episode.projetId; // Ou direct si disponible
        }
      } catch (error) {
        console.error('Erreur lors du chargement des détails de la scène:', error);
        this.sceneTitle = 'Scène inconnue';
      }
    },
    async loadPersonnages() {
      try {
        const response = await axios.get('/api/personnages');
        this.personnages = response.data;
      } catch (error) {
        console.error('Erreur lors du chargement des personnages:', error);
      }
    },
    async loadDialogues() {
      try {
        const response = await axios.get('/api/dialogues');
        this.dialogues = response.data;
      } catch (error) {
        console.error('Erreur lors du chargement des dialogues:', error);
      }
    },
    async submitForm() {
      try {
        let response;
        if (this.isEditing) {
          response = await axios.put(`/api/dialogues/${this.editingId}`, this.formData);
          alert('Dialogue modifié avec succès!');
        } else {
          response = await axios.post('/api/dialogues', this.formData);
          this.newDialogueId = response.data.id; // Ajout : stocke l'ID du nouveau dialogue (adapte le champ si différent, e.g. idDialogue)
          alert('Dialogue ajouté avec succès!');
          // Redirection immédiate après création, similaire à Add_sequence
          this.$router.push({
            path: `/projet/${this.scene.projetId}/ecran-travail`, // Utilise projetId récupéré via scene
            query: { 
              episodeId: this.scene.episode?.idEpisode || this.scene.sequence.episodeId, // Adapte selon structure
              sequenceId: this.scene.sequence?.idSequence || this.scene.sequenceId 
            }
          });
        }
        this.resetForm();
      } catch (error) {
        console.error('Erreur lors de la soumission du dialogue:', error);
        // alert('Erreur: ' + (error.response?.data?.message || error.message));
      }
    },
    resetForm() {
      this.formData = {
        sceneId: '',
        personnageId: null,
        texte: '',
        ordre: 1,
        observation: ''
      };
      this.isEditing = false;
      this.editingId = null;
    },
    formatDate(dateString) {
      if (!dateString) return '';
      return new Date(dateString).toLocaleDateString('fr-FR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    },
    goBack() {
      if (this.newDialogueId && !this.isEditing) { // Ajout : si création, redirige avec query pour sélectionner la séquence
        this.$router.push({
          path: `/projet/${this.scene.projetId}/ecran-travail`,
          query: { 
            // episodeId: this.scene.episode?.idEpisode || this.scene.sequence.episodeId,
            sequenceId: this.scene.sequence?.idSequence || this.scene.sequenceId 
          }
        });
      } else {
        this.$router.go(-1); // Sinon, retour simple
      }
    },

    toggleProfileMenu() {
      this.showProfileMenu = !this.showProfileMenu;
    },
    handleClickOutside(event) {
      if (!event.target.closest('.profile-section')) {
        this.showProfileMenu = false;
      }
    },
    seDeconnecter() {
      localStorage.removeItem('user');
      localStorage.removeItem('token');
      this.$router.push('/');
    },
  }
};
</script>